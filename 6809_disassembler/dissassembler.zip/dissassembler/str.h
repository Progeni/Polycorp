/*
	STR.H
	-----
*/
#ifndef __STR_H__
#define __STR_H__

#include <string.h>

/*
	STRNEW()
	--------
*/
inline char *strnew(char *string)
{
return strcpy(new char [strlen(string) + 1], string);
}

#endif __STR_H__
